function [matrix] = initialize_weights(L_prev, L_next)
  % L_prev -> the number of units in the previous layer
  % L_next -> the number of units in the next layer

  % matrix -> the matrix with random values
  
  % TODO: initialize_weights implementation
  num = sqrt(6) / sqrt(L_prev + L_next);
  % formula for obtaining random elements
  matrix = 2 * num * rand(L_next, L_prev + 1) - num;
endfunction
